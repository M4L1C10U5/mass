Thanks for downloading this template!

Template Name: Hidayah
Template URL: https://bootstrapmade.com/hidayah-free-simple-html-template-for-corporate/
Author: BootstrapMade.com
License: https://bootstrapmade.com/license/
